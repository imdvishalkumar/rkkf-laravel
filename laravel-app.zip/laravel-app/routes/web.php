<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\StudentController;
use App\Http\Controllers\BranchController;
use App\Http\Controllers\FeeController;
use App\Http\Controllers\AttendanceController;
use App\Http\Controllers\ProductController;

// Authentication Routes
Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');
Route::post('/login', [AuthController::class, 'login']);
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

// Protected Routes
Route::middleware(['auth'])->group(function () {
    Route::get('/', [DashboardController::class, 'index'])->name('dashboard');
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
    
    // Student Routes
    Route::resource('students', StudentController::class);
    Route::patch('students/{student}/deactivate', [StudentController::class, 'deactivate'])->name('students.deactivate');
    Route::post('students/{student}/reset-password', [StudentController::class, 'resetPassword'])->name('students.reset-password');
    
    // Branch Routes
    Route::resource('branches', BranchController::class);
    
    // Fee Routes
    Route::resource('fees', FeeController::class);
    
    // Attendance Routes
    Route::get('attendance', [AttendanceController::class, 'index'])->name('attendance.index');
    Route::post('attendance/show-form', [AttendanceController::class, 'showForm'])->name('attendance.show-form');
    Route::post('attendance', [AttendanceController::class, 'store'])->name('attendance.store');
    Route::get('attendance/get-students', [AttendanceController::class, 'getStudents'])->name('attendance.get-students');
    
    // Product Routes
    Route::resource('products', ProductController::class);
});
