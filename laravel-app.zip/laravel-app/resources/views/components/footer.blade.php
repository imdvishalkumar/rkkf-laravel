<footer class="main-footer">
    <strong>Copyright &copy; 2020 <a href="http://www.rkkf.co.in/">RKKF</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
        <b>Version</b> 0.1-pre
    </div>
</footer>

